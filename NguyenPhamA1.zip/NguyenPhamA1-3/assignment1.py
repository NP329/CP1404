""""
Name: PHAM KHOI NGUYEN( 13519001)
PROJECT PURPOSE: Travel tracking
Github link: https://github.com/NP329/CP1404
"""
"The program displays a list of places which can either visited or havent visited as well as addding places too"
''''''''''''''''''

"Operation"
#open csv file places.csv
#return places
def load_places():
    places=open("places.csv","r+")
    return places
''''''
"Details"
"Function: Main"



def main():
    print("Hello!!! Travel Tracking by Nguyen Pham")
    list = load_places()
    places = list.readlines()
    print("{} places are loaded ".format(len(places)))
    places = sortPlaces(places)
    newPlace = menu(places)
    print("{} places will be saved to places.csv ".format(len(places)))
    newPlace = listToString(newPlace)
    list.seek(0)
    list.truncate()
    list.write(newPlace)
    list.close()
    print("Have a great day <3")
"Function: Main"
"Detail: in this function, the program displays the menu table for the user to choose whether to list out places, add places"
"Or mark places"

def menu(places):
    while True:
        print("MENU:")
        print("L - Option: List of places")
        print("A - Option: Add a new place")
        print("M - Option: Mark a place as visited")
        print("Q - Option: Quit")
        choice = input().upper()
        if choice == "L":
            places = list_places(places)
        elif choice == "A":
            places = add_place(places)
        elif choice == "M":
            places = mark_places(places)
        elif choice == "Q":
            return places
        else:
            print("Invalid MENU choice")
"Function: list place"
"Detail: In this function, the program search through the number of visited place and unvisited place from places.csv"
"And display the place list from places.csv"
def list_places(places):
    count = 0
    placenumCount = 1
    placeCount = 0
    for each in places:
        count += 1
        if each[3]=="n":
            print("{:2}.   {:50}-by {:30}({:3}) ".format(count, each[0], each[1], each[2]))
        else:
            print("{:2}.*  {:50}-by {:30}({:3}) ".format(count, each[0], each[1], each[2]))
        if each[3] == 'v':
            placenumCount += 1
        placeCount += 1
        visited_count = placeCount - placenumCount
    print(" {} marked as visted , {} still more to visit".format(visited_count, placenumCount))
    return places
"Function: add place"
"Details: adding places to the list place in places.csv "
def add_place(places):
    visited_count=2
    while True:
        name = input("Please enter Name: ")
        if name == "":
            print("ERROR FOUND!!!! must not be blank")
        else:
            break
    while True:
        country = input("Please enter Country: ")
        if country == "":
            print("Error!!! Input must not be blank")
        else:
            break
    while True:
        try:
            priority = int(input("Please enter priority: "))
            if priority < 0:
                print("Error !!! Number must be >= 0")
            else:
                break
        except ValueError:
            print("Invalid input; Please enter a valid number")


    print(name, "of",country,"(", priority, ") successfully added to place list ")
    places.append([name, country, priority,"v",])
    places = sortPlaces(places)
    return places

"Function: mark place"
"Details: User input place number"
"Check if all places in places.csv is completed if there is place required to complete continue"
"For loop to check each place has yet been visited"
"Run funcion list_places(), load list of places"
"Resulting message that asks for the place number user wants to complete"
"Program check whether that place is visited to either display a proper message for user"
"In case place has not been visited, continue and display a message informing user"
"That place has succcesful been visited"
"Return places"
def mark_places(places):
    required=0
    for each in places:
        if each[3]=="v":
            required=1
        if required==0:
            print("No place visited")
            return places
    list_places(places)
    print("Enter the number of place marked as visited")
    while True:
        place_num=int(input(""))
        try:
            if places[place_num][3]=="n":
                print("This place is already visited")
                break
            else:
                print("{} by {} successfully marked as visited".format(places[place_num][0],places[place_num][1]))
                places[place_num][3]="n"
                break
        except ValueError:
            print("Invalid input; Please enter a valid number")
    return places

"Function: sort place"
"Detail: Sorting the list of places so it will display in Alphabet arragement"

def sortPlaces(places):
    sortedList = []
    for each in places:
        try:
            each = each.strip().split(",")
        except AttributeError:
            pass
        sortedList.append(each)
    newList = sorted(sortedList, key=lambda x:int(x[2]))
    newList = sorted(newList, key=lambda x:x[1])
    return newList


"Function list to String(places)"
"Details: Return data from places to string type"


def listToString(places):
    newString = ""
    for each in places:
        for word in each:
            newString += str(word)+","
        newString = newString[:-1]
        newString += "\n"
    return newString

main()
