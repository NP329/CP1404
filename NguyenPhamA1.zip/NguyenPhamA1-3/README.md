# CP1404 2018 SP2 Assignment 1
Assignment 1 for CP1404, 2017 SP2, IT@JCU

Edit this README file, replacing this paragraph with your own assignment details.  
At the end of the project, complete the very brief project reflection below by answering the questions (replace the `answer...` parts).  
Note: If you use the free WakaTime service on your own machine, you can track exactly how long you spent in code. See https://trello.com/c/6H24THnj/21-wakatime-time-tracking-for-ides-join-our-leaderboard

1. How long did the entire project (assignment 1) take you?
> it took me 2 weeks to do 


2. What do you plan to do  differently in your development process for assignment 2?
> revise previous lecture and ask my lecutre sometimes for advice.
