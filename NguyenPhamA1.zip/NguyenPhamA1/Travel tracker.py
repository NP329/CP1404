"""
Name : Pham Khoi Nguyen
Student ID : 13519001
Assignment 1: Travel Tracker 1.0
Github : https://github.com/jc473949/traveltracker.py
"""


'Pseudocode for algorithms'
# The program will load the songs from songs.csv
# A menu is displayed so that user can make choices: listing all songs, adding a song or complete a song
# The program then saves user's changes, then edits the original csv file

place_names = []
place_country = []
place_priority = []
place_visit = []



'Sub main()'

def main():
    # print welcome message
    print("Travel Tracker 1.0 - by <PhamKhoiNguyen>")
    # call load_places() and menu()
    load_places()
    menu()



'Function: load_places()'

def load_places():
    # Load places.csv
    in_file = open("places.csv", 'r')
    # Loop from beginning to end of file
    for line in in_file:
        # Split up read line by ','
        place_item = line.split(',')
        # Save the place names to a list (place_names)
        place_names.append(place_item[0])
        # Save the place country to a list (place_country)
        place_country.append(place_item[1])
        # Save the place priority to a list (place_priority)
        place_priority.append(int(place_item[2]))
        # Take away "\n" from the 4th item in the list
        place_item[3] = place_item[3].strip('\n')

        # Convert songs learned from "y" to " ", "n" to "*"
        if place_item[3] == "y":
            place_item[3] = " "
        if place_item[3] == "n":
            place_item[3] = "*"

        # Save this change to the list
        place_visit.append(place_item[3])
    # Close File
    in_file.close()

    # Print the number of places that is loaded.
    print("{} places loaded".format(len(place_names)))




'Function: menu()'

def menu():
    # Loop while the conditions given below are true
    while True:
        # Print the menu with list of options
        print("Menu:")
        print("L - List places")
        print("A - Add new place")
        print("C - Mark a place as visited")
        print("Q - Quit")
        # Input the choice the user want to make
        choice = input(">>> ").upper()
        # List all places
        if choice == "L":
            list_all_places()
        # Add place
        elif choice == "A":
            add_new_places()
        # Learn the complete place
        elif choice == "C":
            complete_places()
        # Quit
        elif choice == "Q":
            save_places()
            # Print farewell message
            print("Have a nice day :)")
        else:
            print("Invalid input; enter a valid number")




'Function: list_all_places()'

def list_all_places():
    # Print all loaded places
    for i in range(0, len(place_names)):
        print(" {0}. {1} {2:30} - {3:30} ({4})".format(i, place_visit[i], place_names[i], place_country[i],
                                                       place_priority[i]))
    # Print the number of places visit, and to visit.
    print("{} places visit, {} places still to learn".format(place_visit.count(" "), place_visit.count("*")))




'Function: add_new_place()'

def add_new_place():
    # Loop
    while True:
        # User input a place name of their choice
        new_place = input("Title: ")
        if new_place == "":
            print("Input cannot be blank")
        else:
            break
    while True:
        # User input a place country of their choice.
        new_country = input("Country: ")
        if new_country == "":
            print("Input cannot be blank")
        else:
            break
    while True:
        # User input a song priority of their choice.
        try:
            new_priority = int(input("Priority: "))
            if new_priority < 0:
                print("Number must be >= 0")
            else:
                break
        except ValueError:
            print("Invalid; enter a valid number")
    print("{} by {} ({}) added to place list".format(new_place, new_country, new_priority))



'Function: complete_places()'

def complete_places():
    # User input the place they want to travel.
    any_place = int(input("Enter the number of place marked as visited "))
    try:
        # Loop as long as the place number is in the range of place numbers in the csv file
        if 0 <= any_place < len(place_names):
            # delete the asterisk symbol when the place is visited
            if place_visit[any_place] != " ":
                place_visited[any_place] = " "
                print("{} by {} visited".format(place_names[any_place], place_country[any_country]))
            else:
                print("You have already visited {} ".format(place_names[any_place], place_country[any_country]))
        else:
            print("Invalid; enter a valid number")
    except ValueError:

        print("Invalid; enter a valid number")


'Function: save_places()'


def save_places():
    # open the csv file places.csv and edit the contents
    out_file = open("places.csv", 'w')
    # Loop till the end of list
    for i in range(0, len(place_names)):
        # Change the notations from "*" and " " back to "y" and "n"
        save_place_visit = place_visit[i]
        if save_place_visit == " ":
            save_place_visit = "y"
        if save_place_visit == "*":
            save_place_visit = "n"
        print("{},{},{},{}".format(place_names[i], place_country[i], place_priority[i], save_place_visit), file=out_file)

    out_file.close()


if __name__ == '__main__':
    main()
