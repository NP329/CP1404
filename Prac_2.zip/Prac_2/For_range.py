for i in range(0, 101, 50):
    print("{:>6}".format(i))