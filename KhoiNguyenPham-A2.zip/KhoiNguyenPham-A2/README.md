# CP1404/5632 Assignment: Songs To Learn by YOURNAME

_Edit this README, replacing this line and above with your own assignment details._  
_At the end of the project, complete the project reflection below by answering the questions (replace the ... parts)._
_Note that to get full marks for this, your reflection should match the "exemplary" description from the rubric:_

> The project reflection is complete and describes development and learning well, shows careful thought, highlights insights made during code development.



## 1. How long did the entire project (assignment 2)?
Ans: 1 weeks to do

Note: You may like to use the WakaTime plugin, which tracks exactly how long you spend in code. See http://wakatime.com (but note that the free version only has a 7-day history)

## 

##2. What are you most satisfied with?
 
Ans:I managed to finish the project on time

##3. What are you least satisfied with?
 
Ans: It is hard to set up the layout in the first place, sometimes, the file doesnt link up together because of missed spell words and forgoten "", or missing space can cause the problem to me as well.
My app cannot run perfectly. 
##4. What worked well in your development process?
 
Ans: The places can load after the first run, im happy with it

##5. What about your process could be improved the next time you do a project like this?

Ans: I should find out more about about Kivy before i did like this time, the lack of experience and time constrain really had me a heachache, i will manage my time to have more time to do the project.

##6. Describe what resources you used and how you used them?
Ans: I watched Youtube, search Google, ask my lecture and my friends to help debug sometimes( when i really cannot)

##7. Describe the main challenges or obstacles you faced and how you overcame them?
Ans:Sometimes, one missed spell along the way can cost me 1 hour to find the fault which is annoying and tiring.To become such hard time, a learner like me must not to give up
.However, Python is a good way to learn how to code probably