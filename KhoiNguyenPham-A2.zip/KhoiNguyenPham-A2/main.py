"""
Name: VU HOANG NINH Date of submission : 24th May 2018
Project purpose: This project opens the song list using kivy app of the song list , 
help the user interacts to find and learn the songs they want
GitHub URL: https://github.com/CP1404-2018-51/a2-VUHOANGNINH
"""

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.button import Button
from kivy.properties import StringProperty
from placelist import PlaceList



class PlaceToVistiApp(App):
    """
    The main program is Kivy-app to demomstrate song-list system
    """
    status_text = StringProperty()
    status_text2 = StringProperty()
    def __init__(self, **kwargs):
        """
        :Parameter:**kwargs
        Initiate the self.song_list to SongList() class
        :return:None
        """
        super(PlaceToVistiApp, self).__init__(**kwargs)
        self.place_list = PlaceList()
    def build(self):
        """
        Build the Kivy GUI
        :return: reference to the root Kivy widget
        """
        self.title = "PHAM KHOI NGUYEN - Place List"
        self.root = Builder.load_file('app.kv')
        self.create_entry_buttons() 
        #all places displayed on the screen

        return self.root

    def create_entry_buttons(self):
        """
        The entry buttons  
        add them to the GUI
        :return: None
        """
        num_place=0
        visited_num=0
        self.root.ids.entriesBox.clear_widgets()
        for each in self.place_list.list_place:
            # create a button for each place entry
            num_place+=1 #Add up the number of song for every song looped in the list

            if each.status == "n":
                temp_button = Button(text="{} by {} ({}) ({})".format(each.name,each.country,each.priority,"visited"))
            else:
                temp_button = Button(text="{} by {} ({}) ".format(each.name,each.country,each.priority))
                temp_button.bind(on_release=self.press_entry)
                temp_button.bind(on_release=each.markPlacevisited)
            self.root.ids.entriesBox.add_widget(temp_button)
            if each.status =="n":
                temp_button.background_color = [1,0,1,1] 
                #turn background color into purple COLOR
                visited_num+=1
            else :
                temp_button.background_color = [2,1,1,2] 
                #turn background color button into pink COLOR
        self.status_text = "To learn:{} learned :{}".format(num_place-visited_num,visited_num)
    def press_entry(self, instance):
        """
        Handler for pressing entry buttons
        :param instance: 
        the Kivy button instance
        :return: None
        """
        name = instance.text

        self.status_text2 = "You have not visited {}".format((self.place_list.get_place(name)))
        # This would update the bottom label once the user presses on the temp_button
        instance.state = 'normal'
        #ERROR found: failed to update the bottom label text.

    def clear_text(self):
        """
        Usability:
        _Clear any buttons that have been selected 
        _Reset status text
        :return: None
        """
        # use the .children attribute to access all widgets that are "in" another widget
        self.root.ids.Name.text = ""
        self.root.ids.Country.text = ""              #Empty the text boxes
        self.root.ids.Priority.text = ""
        for instance in self.root.ids.entriesBox.children:    #Normalise the button state
            instance.state = 'normal'
        self.root.ids.statusLabel2.text="" #Empty the status label text box

    def add_place(self):
        """
        Handler for pressing the add button
        :return: None
        """

        if self.root.ids.Name.text == "" or self.root.ids.Country.text == "" or self.root.ids.Priority.text == "":
            self.root.ids.statusLabel.text = "All fields must be required"#Displayed when user does not fill in all the field and press Add Place
            return
        try:
            YEAR = int(self.root.ids.Priority.text) #Make sure the priority text is a number
            self.place_list.AddPlaceToPlaceList(self.root.ids.Name.text,self.root.ids.Country.text,self.root.ids.Priority.text,"n")#Return to function from placelist
            temp_button = Button(text="{} by {} ({}) ({})".format(self.root.ids.Name.text,self.root.ids.Country.text,self.root.ids.Priority.text,"y"))
            temp_button.bind(on_release=self.press_entry)
            temp_button.background_color = [2,1,1,2]        #Append the new temp button with color pink
            self.root.ids.entriesBox.add_widget(temp_button)#Adding widget temp_button
            self.root.ids.Name.text = ""
            self.root.ids.Country.text = "" #Empty the text boxes
            self.root.ids.Priority.text = ""
        except ValueError:
            self.status_text2="Please enter a valid number"#Display status label at the buttom

    def on_stop(self):
        """
        Saves the places to the csv file by calling the save_places
        :return: None
        """
        self.place_list.save_places()
    def press_refresh(self):
        """
        Refresh the page whether the user learn places or choose to sort by name or country or priority from the spinner
        :return: None
        """
        self.place_list.sort_places(self.root.ids.spinner.text) #Sort_places based on the text on the spinner
        self.create_entry_buttons() #Recreate the entry button whenever you click
        #This Button supposes not to be included in the Gui layout and could be worked independently for each temp button and for the spinner , 
        #it does not undo the songs that have been learned.
        #Keeping button helps a more convenient way to show the result after pressing it .

    def clear_fields(self):
        """
        Clear the Name , Country , Priority boxes ( everything)
        :return: None
        """
        self.root.ids.Name.text = ""
        self.root.ids.Country.text = ""
        self.root.ids.Priority.text = ""


PlaceToVistiApp().run()
