# create your SongList class in this file
# create your SongList class in this file
from operator import attrgetter
from place import Place


class PlaceList:
    def __init__(self,file = ""):
        """
        initiate the self attribute list_place
        calls  to the load places to immediately update the placelist
        :return: None
        """
        self.list_place = [] #Initiate list_place as a list that contains all the places
        self.load_places() #Initiate the place_list function
    def get_place(self,text):
        """
        1.Get through the whole list place ,
        2.get the name and return it,
        3.return: each.name
        """
        for each in self.list_place:
        #Loop through the whole song list
            text2 = ("{} by {} ({}) ({}) ({})".format(each.name,each.country,each.priority,"visited"))
        #create a new variable called text2 that has the same format to the text in the button
            if text2 == text: #Condition to find the place with same text
                return each.name #Returns the title of that place
        #This Function supposes to help to update the buttom label 
        #whenever user clicks on the place_button so that it reveals the user that place is learnt
                
    def AddPlaceToPlaceList(self,name,country,priority,status):
        """
        Append new place to the place list
        Sort the place list
        :return: none
        """
        newPlace=Place(name,country,priority,'y') #Create a new variable called newPlace
        self.list_place.append(newPlace) #Append new added Place to the list place
        self.sort_places() #Sort List Place with new Place in the List
    def load_places(self):
        """
        Load and sort places , append new format for the place list .
        return the list place for usage
        :return: self.list_place
        """

        self.file=open("places_backup.csv","r")
         #Load files from places.csv
        list_place = self.file.readlines()
        #Append list_place list with each lines of csv
        for each in list_place:
            each = each.strip().split(',')#Strip off the comma ',' from the csv line
            formatted_Place = Place(each[0],each[1],int(each[2]),each[3])
        #Append name , country , priority to variable formatted_Place , which basically formatted place that would be put to list place to use
            self.list_place.append(formatted_Place)
        # Append every formatted Place to the place_list
        self.sort_places(self)
        return self.list_place
    def save_places(self):
        """
        Save the place list to csv after closing the kivy demo
        :return: none
        """
        csv_string= "" #Create a new string called csv_string that would fit the format of the new CSV file
        for each in self.list_place: #Loop through the whole list place
            csv_string +="{},{},{},{}\n".format(each.name,each.country,each.priority,each.status)
        #Define the csv_string with a suitable format for the csv.file with ',
        #' between name , country and priority
        out_file = open("places_backup.csv",'w')
        out_file.seek(0)
        out_file.truncate()
        out_file.write(csv_string) 
        #Save a newly written out_file to csv.file places.csv
        out_file.close()
    def sort_places(self,name):
        """
        Sort the place list based on the spinner
        and selected
        :return: none
        """
        if name=="Name": #If the Spinner text is Name
            self.list_place=sorted(self.list_place,key=attrgetter("name"))
        #Sort the list_place and temp_button with attributes getter ("name") (Sort by name)
        if name=="Country":#If the Spinner text is Country
            self.list_place=sorted(self.list_place,key=attrgetter("country"))
        #Sort the list_place and temp_button with attributes getter("country") (Sort by country)
        if name=="Priority":#If the Spinner text is Priority
            self.list_place=sorted(self.list_place,key=attrgetter("priority"))
        #Sort the list_place and temp_button with attributes getter("priority") (Sort by priority)

