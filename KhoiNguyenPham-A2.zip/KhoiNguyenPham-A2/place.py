# create your Place class in this file
# !!! NOTE : Place class interact with place only

class Place:
    def __init__(self,name = "",country = "",priority = 0,status=""):
    #These parameters display the characters of a book should have ,
    # should be labeled in order.
        self.country = country
        self.name = name
        self.priority = priority
        self.status= status
    def __str__(self):
        if self.status =="v":
            status= "visited"
            return ("You have visited {} {} ({})".format(self.country, self.name, self.priority))
        else:
            status= ""
            return ("You have not visited {} {} ({})".format(self.country, self.name, self.priority))
    def markPlacevisited(self, *args):

        """
        Change the status to the place to visit
        by click it
        :return: status
        """
        self.status="n"
        return self.status